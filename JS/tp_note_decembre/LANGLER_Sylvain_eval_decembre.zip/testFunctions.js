// Test des fonctions max, min, avg

/*let t = [12, 56, 78, -12, 789];
let w = [12, '56', '78', '-12', '789'];
let z = [12, 45, "se", 456];*/

//console.log(t.max());
//console.log(w.max());
//console.log(z.max());

//console.log(t.min());
//console.log(w.min());
//console.log(z.min());

//console.log(t.avg());
//console.log(w.avg());
//console.log(z.avg());

